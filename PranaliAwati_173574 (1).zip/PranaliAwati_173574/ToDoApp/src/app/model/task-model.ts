export class TaskModel {
    taskName: String;
    taskStatus: String;
}
